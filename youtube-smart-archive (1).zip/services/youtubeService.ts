
import { Video, ChannelInfo } from '../types';

export const CHANNEL_ID = 'UC09bE-qRBo72IIQ54Xaf-EA';
const BASE_URL = 'https://www.googleapis.com/youtube/v3';

// Chiave API YouTube
const YOUTUBE_API_KEY = 'AIzaSyCDCsEZ_BHN6fSCvAbNkd9Gx-FV84f9_wI';

export class YouTubeApiError extends Error {
  constructor(public message: string, public status?: number) {
    super(message);
    this.name = 'YouTubeApiError';
  }
}

export const fetchChannelVideos = async (): Promise<Video[]> => {
  const apiKey = YOUTUBE_API_KEY || (typeof process !== 'undefined' ? process.env.API_KEY : '');
  
  if (!apiKey) {
    throw new YouTubeApiError("Chiave API YouTube non configurata correttamente.");
  }

  // Il metodo UU è il più veloce ma non sempre affidabile per ogni tipo di canale
  const uploadsPlaylistId = CHANNEL_ID.replace(/^UC/, 'UU');
  
  try {
    console.log("Tentativo recupero video tramite ID Playlist Uploads...");
    return await fetchVideosFromPlaylist(uploadsPlaylistId, apiKey);
  } catch (error) {
    console.warn("Metodo UU fallito, provo fallback tramite ContentDetails del canale...", error);
    try {
      return await fetchViaChannelInfo(apiKey);
    } catch (fallbackError) {
      console.error("Entrambi i metodi di caricamento sono falliti.");
      throw fallbackError;
    }
  }
};

const fetchVideosFromPlaylist = async (playlistId: string, apiKey: string): Promise<Video[]> => {
  let allVideos: Video[] = [];
  let nextPageToken: string | undefined = undefined;

  do {
    const url: string = `${BASE_URL}/playlistItems?part=snippet,contentDetails&maxResults=50&playlistId=${playlistId}&key=${apiKey}${nextPageToken ? `&pageToken=${nextPageToken}` : ''}`;
    
    const response = await fetch(url);
    const data = await response.json();

    if (!response.ok) {
      // Se è un errore di quota o chiave, non serve riprovare il fallback
      const msg = data.error?.message || "Errore API YouTube";
      throw new YouTubeApiError(msg, response.status);
    }

    const fetchedVideos = (data.items || []).map((item: any) => ({
      id: item.contentDetails.videoId,
      title: item.snippet.title,
      description: item.snippet.description,
      thumbnail: item.snippet.thumbnails.high?.url || item.snippet.thumbnails.medium?.url || item.snippet.thumbnails.default?.url,
      publishedAt: item.snippet.publishedAt,
      tags: []
    }));

    allVideos = [...allVideos, ...fetchedVideos];
    nextPageToken = data.nextPageToken;
    
    // Sicurezza: evitiamo loop infiniti se l'API impazzisce (max 1000 video per ora)
    if (allVideos.length > 1000) break;

  } while (nextPageToken);

  console.log(`Caricati con successo ${allVideos.length} video.`);
  return allVideos;
};

const fetchViaChannelInfo = async (apiKey: string): Promise<Video[]> => {
  const channelRes = await fetch(`${BASE_URL}/channels?part=contentDetails&id=${CHANNEL_ID}&key=${apiKey}`);
  const channelData = await channelRes.json();
  
  if (!channelRes.ok || !channelData.items?.[0]) {
    throw new YouTubeApiError("Canale non trovato o errore recupero metadati.");
  }

  const playlistId = channelData.items[0].contentDetails.relatedPlaylists.uploads;
  return await fetchVideosFromPlaylist(playlistId, apiKey);
};

export const fetchChannelInfo = async (): Promise<ChannelInfo> => {
  const apiKey = YOUTUBE_API_KEY || (typeof process !== 'undefined' ? process.env.API_KEY : '');
  try {
    const response = await fetch(`${BASE_URL}/channels?part=snippet&id=${CHANNEL_ID}&key=${apiKey}`);
    const data = await response.json();
    
    if (!response.ok || !data.items?.[0]) {
      return { id: CHANNEL_ID, title: 'Karaoke Italiano', description: '', thumbnail: '' };
    }

    const snippet = data.items[0].snippet;
    return {
      id: CHANNEL_ID,
      title: snippet.title,
      description: snippet.description,
      thumbnail: snippet.thumbnails.medium?.url || snippet.thumbnails.high?.url || '',
      customUrl: snippet.customUrl
    };
  } catch (err) {
    return { id: CHANNEL_ID, title: 'Karaoke Italiano', description: '', thumbnail: '' };
  }
};
