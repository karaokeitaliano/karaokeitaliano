
import { GoogleGenAI, Type, GenerateContentParameters } from "@google/genai";
import { Video } from '../types';

export interface GeneratedArticle {
  title: string;
  content: string;
}

const TEXT_MODEL = 'gemini-3-flash-preview';

const sleep = (ms: number) => new Promise(resolve => setTimeout(resolve, ms));

async function generateWithRetry(params: GenerateContentParameters, retries = 3, delay = 3000): Promise<string | undefined> {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  
  for (let i = 0; i < retries; i++) {
    try {
      const response = await ai.models.generateContent(params);
      return response.text;
    } catch (error: any) {
      const isQuotaError = error?.message?.includes('429') || error?.status === 429 || error?.message?.includes('RESOURCE_EXHAUSTED');
      
      if (isQuotaError && i < retries - 1) {
        console.warn(`[Gemini AI] Quota esaurita, riprovo tra ${delay}ms... (Tentativo ${i+1}/${retries})`);
        await sleep(delay);
        delay *= 2; 
        continue;
      }
      throw error;
    }
  }
  return undefined;
}

export const generateArticles = async (): Promise<GeneratedArticle[]> => {
  const topics = [
    '5 Consigli per non stonare mai: La guida definitiva',
    'Karaoke Terapia: Perché cantare allunga la vita',
    'Come configurare il tuo impianto karaoke domestico perfetto'
  ];

  try {
    const text = await generateWithRetry({
      model: TEXT_MODEL,
      contents: `Sei un esperto di musica. Genera 3 brevi articoli di blog (150 parole l'uno) basati su questi titoli: ${topics.join(', ')}. 
      Restituisci ESCLUSIVAMENTE un array JSON di oggetti con chiavi 'title' e 'content' (usa HTML per paragrafi nel content).`,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.ARRAY,
          items: {
            type: Type.OBJECT,
            properties: {
              title: { type: Type.STRING },
              content: { type: Type.STRING }
            },
            required: ['title', 'content']
          }
        }
      }
    });

    if (!text) return [];
    return JSON.parse(text.trim());
  } catch (error) {
    console.error("Errore generazione articoli:", error);
    return [];
  }
};

export const enrichVideosWithAI = async (videos: Video[]): Promise<Video[]> => {
  if (!videos || videos.length === 0) return [];

  const CHUNK_SIZE = 10; 
  const enrichedVideos = [...videos];

  const processChunk = async (chunk: Video[]) => {
    try {
      const prompt = `Analizza questi brani karaoke. Identifica Artista e Genere (Pop, Rock, Sanremo, Cantautorato, Anni 80). 
      Dati: ${JSON.stringify(chunk.map(v => ({ id: v.id, title: v.title })))}`;

      const text = await generateWithRetry({
        model: TEXT_MODEL,
        contents: prompt,
        config: {
          responseMimeType: 'application/json',
          responseSchema: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                id: { type: Type.STRING },
                artist: { type: Type.STRING },
                aiCategory: { type: Type.STRING },
                aiSummary: { type: Type.STRING }
              },
              required: ['id', 'artist', 'aiCategory', 'aiSummary']
            }
          }
        }
      });

      if (!text) return;
      const aiData = JSON.parse(text.trim());
      
      aiData.forEach((d: any) => {
        const index = enrichedVideos.findIndex(v => v.id === d.id);
        if (index !== -1) {
          enrichedVideos[index] = { 
            ...enrichedVideos[index], 
            artist: d.artist,
            aiCategory: d.aiCategory,
            aiSummary: d.aiSummary
          };
        }
      });
    } catch (e) {
      console.warn("L'arricchimento IA per questo gruppo è stato ignorato a causa dei limiti di quota.");
    }
  };

  for (let i = 0; i < Math.min(videos.length, 50); i += CHUNK_SIZE) {
    const chunk = videos.slice(i, i + CHUNK_SIZE);
    await processChunk(chunk);
    await sleep(2000); // Pausa per non saturare le API
  }

  return enrichedVideos;
};
