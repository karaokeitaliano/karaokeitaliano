
// File deprecato, utilizzare aiService.ts
export {};
